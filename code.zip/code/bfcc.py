# -*- coding: utf-8 -*-

import numpy as np
from scipy.signal import spectrogram
import matplotlib.pyplot as plt

import pyACA
from pyACA.ToolPreprocAudio import ToolPreprocAudio
from pyACA.ToolComputeHann import ToolComputeHann
from pyACA.ToolReadAudio import ToolReadAudio


def bfcc(cPitchTrackName, afAudioData, f_s, afWindow=None, iBlockLength=4096, iHopLength=2048):
    
    #mypackage = __import__(".Pitch" + cPitchTrackName, package="pyACA")
    hPitchFunc = getattr(pyACA, "Pitch" + cPitchTrackName)

    # pre-processing
    afAudioData = ToolPreprocAudio(afAudioData, iBlockLength)

    if isSpectral(cPitchTrackName):
        # compute window function for FFT
        if afWindow is None:
            afWindow = ToolComputeHann(iBlockLength)

        assert(afWindow.shape[0] == iBlockLength), "parameter error: invalid window dimension"

        [f_k, t, X] = spectrogram(afAudioData,
                                  f_s,
                                  afWindow,
                                  iBlockLength,
                                  iBlockLength - iHopLength,
                                  iBlockLength,
                                  False,
                                  True,
                                  'spectrum')

        X = np.sqrt(X / 2)

        f = hPitchFunc(X, f_s)

    if isTemporal(cPitchTrackName):
        [f, t] = hPitchFunc(afAudioData, iBlockLength, iHopLength, f_s)

    return (f, t)


#######################################################
# helper functions
def isSpectral(cName):
    bResult = False
    if "Spectral" in cName:
        bResult = True

    return (bResult)


def isTemporal(cName):
    bResult = False
    if "Time" in cName:
        bResult = True

    return (bResult)


def computePitchCl(cPath, cPitchTrackName, bPlotOutput=False):
    
    # read audio file
    [f_s, afAudioData] = ToolReadAudio(cPath)
    # afAudioData = np.sin(2*np.pi * np.arange(f_s*1)*440./f_s)
    [v, t] = computePitch(cPitchTrackName, afAudioData, f_s)

    # plot feature output
    if bPlotOutput:
        plt.plot(t, v)

    return (v, t)


if __name__ == "__main__":
    import argparse

    # add command line args and parse them
    parser = argparse.ArgumentParser(description='Compute key of wav file')
    parser.add_argument('--infile', metavar='path', required=False,
                        help='path to input audio file')
    parser.add_argument('--featurename', metavar='string', required=False,
                        help='feature name in the format SpectralPitchChroma')
    parser.add_argument('--plotoutput', metavar='bool', required=False,
                        help='option to plot the output')

    # retrieve command line args
    args = parser.parse_args()
    cPath = args.infile
    cPitchTrackName = args.featurename
    bPlotOutput = args.plotoutput

    # only for debugging
    if __debug__:
        if not cPath:
            cPath = "audiodata/Amyotrophe Lateralsklerose/1242-a_n.wav"
        if not cPitchTrackName:
            cPitchTrackName = "TimeAmdf"
        if not bPlotOutput:
            bPlotOutput = True

    # call the function
    computePitchCl(cPath, cPitchTrackName, bPlotOutput)
