#---global binary pattern---
#---http://kovan.ceng.metu.edu.tr/~sinan/publications/MVA13_Sivri.pdf-----

import numpy as np

# img=np.random.randint(0,255,[200,200])

def gbp(img):
    sz=img.shape
    img2=np.zeros(sz)
    img3 = np.zeros(sz)
    H_val=[2**-2j,2**-1j,2**0,2**-1,2**-2]
    H_matrix=np.repeat(H_val,5).reshape([5,5]).transpose()
    V_val=[2**-1j,2**0,2**-1,2**-2,2**-3]
    V_matrix=np.repeat(V_val,5).reshape([5,5])
    for i1 in range(2,sz[0]-3):
        for i2 in range(2,sz[1]-3):
            grid=img[i1-2:i1+3,i2-2:i2+3]
            H_mul=grid*H_matrix
            H_sum=np.sum(H_mul,0)
            V_mul=grid*V_matrix
            V_sum = np.sum(V_mul, 1)
            GBP_desc=np.mean([H_sum, V_sum])
            img2[i1-2,i2-2]=np.real(GBP_desc)
            img3[i1 - 2, i2 - 2] = np.imag(GBP_desc)

    return (img2,img3)





