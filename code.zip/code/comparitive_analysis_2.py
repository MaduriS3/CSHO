

def comparitive_analysis_1():
    import pandas
    import numpy as np

    import tensorflow as tf
    from tensorflow.keras.models import Sequential, Model
    from tensorflow.keras.utils import to_categorical
    from tensorflow.keras.layers import Dense, Dropout, Activation, Embedding, Conv1D, GlobalMaxPooling1D, Input

    import pickle
    import support_fn
    import csho

    import feature_extraction_1, feature_extraction_2

    data_orig1 = feature_extraction_1.process1()
    data_orig2 = feature_extraction_2.process2()

    data_orig=np.hstack((data_orig1[:,0:-1],np.resize(data_orig2[:,0:30],[data_orig1.shape[0],30]),np.array([data_orig1[:,-1]]).transpose()))
    data_orig=pandas.DataFrame(data_orig)
    data=data_orig.iloc[0:,0:-1]
    labels=data_orig.iloc[0:,-1]
    data = support_fn.normalize_data(data,2)
    sz =data.shape

    acc_all=np.zeros([5,5])
    sen_all=np.zeros([5,5])
    spe_all=np.zeros([5,5])
    for i in range(5):
        kvalue=5+i
        KV=support_fn.split_kfold_uniquely(labels,kvalue)
        logi=KV[0,:]>0

        tr_data=data.iloc[np.logical_not(logi),:]
        tr_lab = labels[np.logical_not(logi)]
        tst_data = data.iloc[logi, :]
        tst_lab = labels[logi]

        sz = tr_data.shape

        n_uq=len(tr_lab.unique())

        # --------Resnet-----------

        input_shape=(sz[1],)
        y_binary1 = to_categorical(tr_lab)
        y_binary2 = to_categorical(tst_lab)
        model = Sequential()
        model.add(Dense(100, input_shape=input_shape, activation='relu'))
        # model.add(Dense(50, activation='relu'))
        model.add(Dense(n_uq, activation='softmax'))
        model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        we=model.get_weights()
        we[0]=we[0] * csho
        model.set_weights(we)
        model.fit(tr_data, y_binary1, epochs=10, batch_size=100, verbose=1)
        pred_5=model.predict(tst_data)
        y_pred_5 = pred_5.argmax(axis=-1)
        M5 = support_fn.get_metrics(tst_lab, y_pred_5)


        acc_now=[M5['acc'].mean()]
        sen_now=[M5['sen'].mean()]
        spe_now=[M5['spe'].mean()]

        acc_all[i,:]=acc_now
        sen_all[i,:]=sen_now
        spe_all[i,:]=spe_now


    result={}
    result['acc']=acc_all
    result['sen']=sen_all
    result['spe']=spe_all
    # Saving the objects:
    # with open('result_2.pkl', 'wb') as f:
    #     pickle.dump(result, f)

if __name__ == '__main__':
    comparitive_analysis_1()





