
import numpy as np
import cv2

def draw_cross_keypoints(img, keypoints, color):
    """ Draw keypoints as crosses, and return the new image with the crosses. """
    img_kp = img.copy()  # Create a copy of img
    # Iterate over all keypoints and draw a cross on evey point.
    pts=[]
    for kp in keypoints:
        x, y = kp.pt
        x = int(round(x))  # Round an cast to int
        y = int(round(y))
        pts.append([x,y])
        # Draw a cross with (x, y) center
        cv2.drawMarker(img_kp, (x, y), color, markerType=cv2.MARKER_CROSS, markerSize=5, thickness=1, line_type=cv2.LINE_8)
    return img_kp,pts

def draw_cross_keypoints2(img, keypoints, color):
    """ Draw keypoints as crosses, and return the new image with the crosses. """
    img_kp = img.copy()  # Create a copy of img
    # Iterate over all keypoints and draw a cross on evey point.
    pts=[]
    for kp in keypoints:
        x, y = kp.pt
        x = int(round(x))  # Round an cast to int
        y = int(round(y))
        pts.append([x,y])
        # Draw a cross with (x, y) center
        # cv2.drawMarker(img_kp, (x, y), color, markerType=cv2.MARKER_SQUARE, markerSize=15, thickness=1, line_type=cv2.LINE_8)
        cv2.circle(img_kp, (x, y), 10, color, thickness=-1, lineType=8, shift=0)
    return img_kp,pts

def SLIF(image1):

    # Convert the training image to RGB
    training_image = cv2.cvtColor(image1, cv2.COLOR_BGR2RGB)
    # Convert the training image to gray scale
    training_gray = cv2.cvtColor(training_image, cv2.COLOR_RGB2GRAY)
    img=np.zeros(training_gray.shape)
    # Create test image by adding Scale Invariance and Rotational Invariance
    test_image = cv2.pyrDown(training_image)
    test_image = cv2.pyrDown(test_image)
    num_rows, num_cols = test_image.shape[:2]
    rotation_matrix = cv2.getRotationMatrix2D((num_cols / 2, num_rows / 2), 30, 1)
    test_image = cv2.warpAffine(test_image, rotation_matrix, (num_cols, num_rows))
    test_gray = cv2.cvtColor(test_image, cv2.COLOR_RGB2GRAY)
    # sift = cv2.SIFT_create()
    sift = cv2.xfeatures2d.SIFT_create()
    train_keypoints, train_descriptor = sift.detectAndCompute(training_gray, None)
    test_keypoints, test_descriptor = sift.detectAndCompute(test_gray, None)
    len_1=len(train_keypoints)
    img_kp,pts_1 = draw_cross_keypoints(img, train_keypoints, color=(1))
    img_kp3, pts_3 = draw_cross_keypoints2(img, train_keypoints, color=(1))
    orb = cv2.ORB_create()
    train_keypoints, train_descriptor = orb.detectAndCompute(training_gray, None)
    test_keypoints, test_descriptor = orb.detectAndCompute(test_gray, None)
    len_2 = len(train_keypoints)
    keypoints_without_size = np.copy(training_image)
    keypoints_with_size = np.copy(training_image)
    img_kp2,pts_2 = draw_cross_keypoints2(img, train_keypoints, color=(1))
    if len_1>len_2:
        out=img_kp2
        pts=pts_2
    else:
        out=img_kp2+img_kp3
        pts=pts_2

    return out,pts


if __name__ == '__main__':
    import matplotlib.pyplot as plt
    img=cv2.imread('orig.png')
    out,pts=SLIF(img)
    pts=np.array(pts)
    plt.figure()
    plt.imshow(img)
    plt.plot(pts[:,0],pts[:,1],'o')
    plt.show()



