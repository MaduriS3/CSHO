from __future__ import division

import os
import numpy as np
# import pandas as pd
import pickle
import cv2
import GBP
import matplotlib.pyplot as plt
import SLIF

def process1():
    base_folder='dataset'
    cate=['Hbv','He','IPCL','Le']

    feat_all=[]
    for i1 in range(len(cate)):
        d1=os.listdir(os.path.join(base_folder,cate[i1]))
        for i2 in range(len(d1)):
            f1=os.path.splitext(d1[i2])
            if (f1[-1].lower()=='.jpg')|(f1[-1].lower()=='.png'):
                img_path=os.path.join(base_folder,cate[i1],d1[i2])
                img_rgb = cv2.imread(img_path)
                sz_orig = img_rgb.shape
                img = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
                img = cv2.normalize(img, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8UC1)
                S_img,pts=SLIF.SLIF(img_rgb)
                # plt.imshow(S_img)
                # plt.show()
                if np.count_nonzero(S_img>0)>0:
                    f1 = np.histogram(img[S_img>0], 20)
                else:
                    f1 = np.histogram(img, 20)
                gbp_im=GBP.gbp(img)
                f2 = np.histogram(gbp_im[0], 30)
                hg=cv2.HOGDescriptor()
                hg_im=hg.computeGradient(img,5,50)
                f3=np.histogram(hg_im[0][:,:,0], 50)

                label=i1
                feat_vec=np.hstack((f2[0],f3[0],label))

                if len(feat_all) == 0:
                    feat_all = feat_vec
                else:
                    feat_all = np.vstack((feat_all, feat_vec))
                print('now=%d/%d,%d/%d' %(i1+1,4,i2+1,len(d1)))

# with open('feat_all_1.pkl', 'wb') as f:
#     pickle.dump(feat_all, f)
#
# print('end')
    return feat_all


