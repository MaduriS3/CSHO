from __future__ import division

import _pickle as cpickle
import os
import pyACA
import numpy as np
# import pandas as pd
import audio_util
from spafe.features.bfcc import bfcc
def process2():
    base_folder='audiodata'
    cate=os.listdir(base_folder)

    feat_all=[]
    for i1 in range(len(cate)):
        d1=os.listdir(os.path.join(base_folder,cate[i1]))
        for i2 in range(len(d1)):
            f1=os.path.splitext(d1[i2])
            if (f1[-1].lower()=='.wav'):
                audio_filename=os.path.join(base_folder,cate[i1],d1[i2])
                x, Fs = audio_util.load_audios(audio_filename)
                sz_orig = x.shape

                f1=pyACA.FeatureSpectralMfccs(x, Fs,10)
                f2=bfcc(x)
                f2 = np.resize(np.mean(f2, 1), 16)
                f3=pyACA.FeatureSpectralCentroid(x,Fs)
                f4=pyACA.FeatureSpectralSkewness(x, Fs)
                f4=f4*1e4
                f5=pyACA.FeatureSpectralFlatness(np.abs(x), Fs)
                f6=pyACA.FeatureSpectralTonalPowerRatio(x, Fs)

                label=i1
                feat_vec=np.hstack((f1,f2[0],f3,f4,f5,f6))
                feat_vec[np.isnan(feat_vec)]=0
                feat_vec=np.resize(feat_vec, [1, 30])
                feat_vec = np.hstack((feat_vec[0],label))

                if len(feat_all) == 0:
                    feat_all = feat_vec
                else:
                    feat_all = np.vstack((feat_all, feat_vec))
                print('now=%d/%d,%d/%d' %(i1+1,4,i2+1,len(d1)))

# with open('feat_all_2.pkl', 'wb') as f:
#     pickle.dump(feat_all, f)
#
# print('end')
    return feat_all


